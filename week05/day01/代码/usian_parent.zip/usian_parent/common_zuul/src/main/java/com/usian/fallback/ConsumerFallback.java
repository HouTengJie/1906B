package com.usian.fallback;

import org.springframework.cloud.netflix.zuul.filters.route.FallbackProvider;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.client.ClientHttpResponse;
import org.springframework.stereotype.Component;

import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.nio.charset.Charset;

@Component
public class ConsumerFallback implements FallbackProvider {
    @Override
    public String getRoute() {
        return "*";
    }


    @Override
    public ClientHttpResponse fallbackResponse(String route, Throwable cause) {
        return new ClientHttpResponse() {
            @Override
            public HttpHeaders getHeaders() {
                HttpHeaders header = new HttpHeaders();
                header.setContentType(MediaType.APPLICATION_JSON_UTF8);
                return header;
            }


            @Override
            public InputStream getBody() throws IOException {
                String content = "该服务暂时不可用，请稍后重试";
                return new ByteArrayInputStream(content.getBytes());
            }


            @Override
            public String getStatusText() throws IOException {
                return this.getStatusCode().getReasonPhrase();
            }


            @Override
            public HttpStatus getStatusCode() throws IOException {
                return HttpStatus.OK;
            }


            @Override
            public int getRawStatusCode() throws IOException {
                return this.getStatusCode().value();
            }
            @Override
            public void close() {

            }
        };
    }
}	