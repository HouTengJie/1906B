package com.usian.controller;

import com.usian.fegin.CartServiceFeign;
import com.usian.pojo.*;
import com.usian.utils.Result;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * 订单服务 Controller
 */
@RestController
@RequestMapping("/frontend/order")
public class OrderController {

    @Autowired
    private CartServiceFeign cartServiceFeign;
    @RequestMapping("/goSettlement")
    public Result goSettlement(String[] ids, String userId) {
        Map<String, TbItem> cart = cartServiceFeign.selectCartByUserId(userId);
        List<TbItem> list = new ArrayList<TbItem>();
        for (int i = 0; i < ids.length; i++){
            String itemId = ids[i];
            list.add(cart.get(itemId));
        }
        if(list.size()>0) {
            return Result.ok(list);
        }
        return Result.error("查询失败");
    }
}    